app.controller('layoutCtrl', function($scope, $rootScope) {

});